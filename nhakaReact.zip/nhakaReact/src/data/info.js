export const subs = [
  {
    id: 'overhead-press',
    title: 'Overhead Press',
    description: 'Delts exercise...',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/01/16/abacus-1866497__340.jpg'
  },
  {
    id: 'dips',
    title: 'Dips',
    description: 'Triceps exercise...',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/01/16/abacus-1866497__340.jpg'
  },
  {
    id: 'barbell-curls',
    title: 'Barbell Curls',
    description: 'Biceps exercise...',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/01/16/abacus-1866497__340.jpg'
  },
  {
    'id': 'bench-press',
    title: 'Bench Press',
    description: 'Chest exercise...',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/01/16/abacus-1866497__340.jpg'
  },
  {
    id: 'pull-ups',
    title: 'Pull Ups',
    description: 'Back and biceps exercise...',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2016/11/29/01/16/abacus-1866497__340.jpg'
  }
]

export const maths = [
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
  {
    id: 'overhead-press',
    title: 'Addition',
    description: 'learning to Add',
	grade: '1',
    image: 'https://cdn.pixabay.com/photo/2017/02/09/16/59/student-2052868__340.jpg'
  },
]